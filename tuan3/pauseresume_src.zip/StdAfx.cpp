/*
	This code is distributed as is with no warranty, Feel free to change use it in any way you like.
	Author is not responsible for anything.
	If you have any problem feel free to contact NarendraChandel@hotmail.com
	Have fun.
*/
// stdafx.cpp : source file that includes just the standard includes
//	PauseResumeDemo.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



